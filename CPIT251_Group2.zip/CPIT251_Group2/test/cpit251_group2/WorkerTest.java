/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpit251_group2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 96653
 */
public class WorkerTest {
    
    public WorkerTest() {
    }

    /**
     * Test of getWorkerName method, of class Worker.
     */
    @Test
    public void testGetWorkerName() {
    }

    /**
     * Test of getWorkerPhone method, of class Worker.
     */
    @Test
    public void testGetWorkerPhone() {
    }

    /**
     * Test of getWorkerEmail method, of class Worker.
     */
    @Test
    public void testGetWorkerEmail() {
    }

    /**
     * Test of getPrice method, of class Worker.
     */
    @Test
    public void testGetPrice() {
    }

    /**
     * Test of getWorkHouer method, of class Worker.
     */
    @Test
    public void testGetWorkHouer() {
    }

    /**
     * Test of getWorkerEvaluation method, of class Worker.
     */
    @Test
    public void testGetWorkerEvaluation() {
    }

    /**
     * Test of setWorkerName method, of class Worker.
     */
    @Test
    public void testSetWorkerName() {
    }

    /**
     * Test of setWorkerPhone method, of class Worker.
     */
    @Test
    public void testSetWorkerPhone() {
    }

    /**
     * Test of setWorkerEmail method, of class Worker.
     */
    @Test
    public void testSetWorkerEmail() {
    }

    /**
     * Test of setPrice method, of class Worker.
     */
    @Test
    public void testSetPrice() {
    }

    /**
     * Test of setWorkHouer method, of class Worker.
     */
    @Test
    public void testSetWorkHouer() {
    }

    /**
     * Test of setWorkerEvaluation method, of class Worker.
     */
    @Test
    public void testSetWorkerEvaluation() {
    }

    /**
     * Test of toString method, of class Worker.
     */
    @Test
    public void testToString() {
    }
    
}
